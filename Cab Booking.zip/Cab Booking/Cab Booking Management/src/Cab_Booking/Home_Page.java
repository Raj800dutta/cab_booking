
package Cab_Booking;

import java.awt.*;
import static java.awt.Color.WHITE;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;

public class Home_Page extends JFrame implements ActionListener
{
   JPanel panel;
   JFrame f;
   JLabel l1,l2,l3,l4,l5,l6,l7;
   JTextField t1;
   JPasswordField pf1;
   JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14; 
   
   Home_Page()
   {
     f=new JFrame("Home Page");
     f.setBackground(Color.WHITE);
     f.setLayout(null);
     
     l1=new JLabel();
     l1.setBounds(0,0,900,600);
     l1.setLayout(null);
     
     ImageIcon img=new ImageIcon(ClassLoader.getSystemResource("Cab_Booking/icons/tt.jpeg"));
     Image i1=img.getImage().getScaledInstance(900,580,Image.SCALE_DEFAULT);
     ImageIcon img1=new ImageIcon(i1);
     l1.setIcon(img1);
     
     l2=new JLabel("Home Page");
     l2.setBounds(345,25,580,80);
     l2.setFont(new Font("Airal",Font.BOLD,30));
     l2.setForeground(Color.YELLOW);
     l1.add(l2);
     f.add(l1);
     
     b1=new JButton("Add Customer Profile");
     b1.setBackground(Color.RED);
     b1.setForeground(Color.WHITE);
     b1.setBounds(50,150,350,40);
     
     b2=new JButton("View Customer Profile");
     b2.setBackground(Color.RED);
     b2.setForeground(Color.WHITE);
     b2.setBounds(450,150,350,40);
     
     b3=new JButton("Update Customer Profile");
     b3.setBackground(Color.RED);
     b3.setForeground(Color.WHITE);
     b3.setBounds(50,200,350,40);
     
     b4=new JButton("Add IntraCity Driver");
     b4.setBackground(Color.RED);
     b4.setForeground(Color.WHITE);
     b4.setBounds(450,200,350,40);
     
     b5=new JButton("Book Intracity Cab");
     b5.setBackground(Color.RED);
     b5.setForeground(Color.WHITE);
     b5.setBounds(50,250,350,40);
     
     b6=new JButton("View Booked Cab");
     b6.setBackground(Color.RED);
     b6.setForeground(Color.WHITE);
     b6.setBounds(450,250,350,40);
     
     b7=new JButton("Add InterCity Driver");
     b7.setBackground(Color.RED);
     b7.setForeground(Color.WHITE);
     b7.setBounds(50,300,350,40);
     
     b8=new JButton("Book Intercity Cab");
     b8.setBackground(Color.RED);
     b8.setForeground(Color.WHITE);
     b8.setBounds(450,300,350,40);
     
     b9=new JButton("View Intercity Booked Cab");
     b9.setBackground(Color.RED);
     b9.setForeground(Color.WHITE);
     b9.setBounds(50,350,350,40);
     
     b10=new JButton("Add Transport Driver");
     b10.setBackground(Color.RED);
     b10.setForeground(Color.WHITE);
     b10.setBounds(450,350,350,40);
     
     b11=new JButton("Book Package");
     b11.setBackground(Color.RED);
     b11.setForeground(Color.WHITE);
     b11.setBounds(50,400,350,40);
     
     b12=new JButton("View Booked Package");
     b12.setBackground(Color.RED);
     b12.setForeground(Color.WHITE);
     b12.setBounds(450,400,350,40);
     
     b13=new JButton("Delete Customer");
     b13.setBackground(Color.RED);
     b13.setForeground(Color.WHITE);
     b13.setBounds(50,450,350,40);
     
     b14=new JButton("Check Bill");
     b14.setBackground(Color.RED);
     b14.setForeground(Color.WHITE);
     b14.setBounds(450,450,350,40);
     
     l1.add(b1);
     l1.add(b2);
     l1.add(b3);
     l1.add(b4);
     l1.add(b5);
     l1.add(b6);
     l1.add(b7);
     l1.add(b8);
     l1.add(b9);
     l1.add(b10);
     l1.add(b11);
     l1.add(b12);
     l1.add(b13);
     l1.add(b14);
     
     b1.addActionListener(this);
     b2.addActionListener(this);
     b3.addActionListener(this);
     b4.addActionListener(this);
     b5.addActionListener(this);
     b6.addActionListener(this);
     b7.addActionListener(this);
     b8.addActionListener(this);
     b9.addActionListener(this);
     b10.addActionListener(this);
     b11.addActionListener(this);
     b12.addActionListener(this);
     b13.addActionListener(this);
     b14.addActionListener(this);
     
     
     f.setVisible(true);
     f.setSize(900,600);
     f.setLocation(300,100);
     f.setResizable(false);
     
   }
    public void actionPerformed(ActionEvent e)
   {
       if (e.getSource()==b1)   
  {
      new Add_Customer().setVisible(true);
    //  this.setVisible(false);
  }
  if (e.getSource()==b2)   
  {
      new View_Customer().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b3)   
  {
      new Update_Customer().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b4)   
  {
      new Add_IntraCity_Driver().setVisible(true);
        //   this.setVisible(false);
  }
       if (e.getSource()==b5)   
  {
      new Book_Intracity_Cab().setVisible(true);
    //  this.setVisible(false);
  }
  if (e.getSource()==b6)   
  {
           new View_BookedCab().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b7)   
  {
           new Add_InterCity_Driver().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b8)   
  {
           new Book_Intercity_Cab().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b9)   
  {
           new View_BookedCab().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b10)   
  {
           new Add_Transport_Driver().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b11)   
  {
           new Book_Package().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b12)   
  {
           new View_Booked_Package().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b13)   
  {
           new Delete_Customer().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==b14)   
  {
           new CheckBill().setVisible(true);
        //   this.setVisible(false);
  }
   }
   public static void main(String[] args)
   {
       new Home_Page();
   }
}