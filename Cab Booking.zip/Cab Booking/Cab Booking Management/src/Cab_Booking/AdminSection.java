/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cab_Booking;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class AdminSection extends JFrame implements ActionListener
{
      JLabel l1;
    JButton bt1,bt2,bt3,bt4;
    JPanel p1,p2;
    Font f,f1;
    AdminSection()
    {
         super("Admin Section");
      setLocation(450,300);
      setSize(850,500);
      
       f=new Font("Arial",Font.BOLD,15);
      f1=new Font("Arial",Font.BOLD,15);
      
      l1=new JLabel("Admin Section");
      bt1=new JButton("Intercity Driver");
      bt2=new JButton("Intracity Driver");
      bt3=new JButton("Transport Driver");
      bt4=new JButton("SignUP");
      
      l1.setHorizontalAlignment(JLabel.CENTER);
      
      bt1.addActionListener(this);
      bt2.addActionListener(this);
      bt3.addActionListener(this);
      bt4.addActionListener(this);
      
        l1.setFont(f);
      bt1.setFont(f1);
      bt2.setFont(f1);
      bt3.setFont(f1);
      bt4.setFont(f1);
      
      p1=new JPanel();
      p1.setLayout(new GridLayout(5,1,5,5));
      p1.add(l1);
      p1.add(bt1);
      p1.add(bt2);
      p1.add(bt3);
      p1.add(bt4);
      
       setLayout(new BorderLayout(10,10));
      add(p1,"Center");
      
    }
    
    public void actionPerformed(ActionEvent e)
    {
  if (e.getSource()==bt1)   
  {
      new Add_InterCity_Driver().setVisible(true);
    //  this.setVisible(false);
  }
  if (e.getSource()==bt2)   
  {
           new Add_IntraCity_Driver().setVisible(true);
        //   this.setVisible(false);
  }
  if (e.getSource()==bt3)   
  {
          new Add_Transport_Driver().setVisible(true);
        //  this.setVisible(false);
  }
  if (e.getSource()==bt4)   
  {
      new Signup().setVisible(true);
        //  this.setVisible(false); 
  }
        
    }
      public static void main(String[] args)
    {
         new AdminSection() .setVisible(true);
    }

}
